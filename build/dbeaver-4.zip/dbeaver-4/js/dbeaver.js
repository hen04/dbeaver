$(function(){

	$('.dbeaver-slider').slick({
		arrows: false,
		dots: true
	});

	$('select').select2({
		placeholder: 'Select'
	});


});
